/*******************************************/
// COMP 345 - Part 4 - Cards deck / hand
// 
// Team DN07, Fall 2022
//
// Assignment 1: Faizan Ahmad 
// Due date: October 9th 2022
/*******************************************/

#pragma once
void testCards();

// EOF