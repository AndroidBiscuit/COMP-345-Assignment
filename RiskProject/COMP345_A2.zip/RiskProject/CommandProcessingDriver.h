#pragma once
void testCommandProcessor();