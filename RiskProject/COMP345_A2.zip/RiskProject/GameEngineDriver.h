#pragma once
void testStartupPhase();
void testMainGameLoop();