#pragma once
void  testLoggingObserver();